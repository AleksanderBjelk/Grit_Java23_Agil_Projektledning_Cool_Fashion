/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./tshirt.html"],
    theme: {
        extend: {
          colors:{
            'grön': '#03ff68'
          }
        },
    },
    plugins: [],
};
